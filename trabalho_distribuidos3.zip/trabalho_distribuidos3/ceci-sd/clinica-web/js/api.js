const API_BASE_URL = 'http://localhost:8080/api';

// Funções genéricas para requisições HTTP
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching data:', error);
        showAlert('Erro ao carregar dados', 'danger');
        return null;
    }
}

async function postData(endpoint, data) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return response;
    } catch (error) {
        console.error('Error posting data:', error);
        showAlert('Erro ao salvar dados', 'danger');
        return null;
    }
}

async function putData(endpoint, data) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return response;
    } catch (error) {
        console.error('Error updating data:', error);
        showAlert('Erro ao atualizar dados', 'danger');
        return null;
    }
}

async function deleteData(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return response;
    } catch (error) {
        console.error('Error deleting data:', error);
        showAlert('Erro ao excluir dados', 'danger');
        return null;
    }
}

// Funções específicas para Pacientes
async function getPacientes() {
    return await fetchData('/pacientes');
}

async function addPaciente(paciente) {
    return await postData('/pacientes', paciente);
}

async function updatePaciente(id, paciente) {
    return await putData(`/pacientes/${id}`, paciente);
}

async function deletePaciente(id) {
    return await deleteData(`/pacientes/${id}`);
}

// Funções específicas para Médicos
async function getMedicos() {
    return await fetchData('/medicos');
}

async function addMedico(medico) {
    return await postData('/medicos', medico);
}

async function updateMedico(crm, medico) {
    return await putData(`/medicos/${crm}`, medico);
}

async function deleteMedico(crm) {
    return await deleteData(`/medicos/${crm}`);
}

// Funções específicas para Consultas
async function getConsultas() {
    return await fetchData('/consultas');
}

async function addConsulta(consulta) {
    return await postData('/consultas', consulta);
}

async function updateConsulta(index, consulta) {
    return await putData(`/consultas/${index}`, consulta);
}

async function deleteConsulta(index) {
    return await deleteData(`/consultas/${index}`);
}

// Funções auxiliares
async function buscarMedicoPorCrm(crm) {
    try {
        const response = await fetch(`${API_BASE_URL}/medicos/${crm}`);
        if (response.ok) {
            return await response.json();
        }
        return null;
    } catch (error) {
        console.error('Erro ao buscar médico:', error);
        return null;
    }
}

async function buscarPacientePorId(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/pacientes/${id}`);
        if (response.ok) {
            return await response.json();
        }
        return null;
    } catch (error) {
        console.error('Erro ao buscar paciente:', error);
        return null;
    }
}

// Função para exibir alertas
function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Remove o alerta após 5 segundos
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}