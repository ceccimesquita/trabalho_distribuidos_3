document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const consultasTableBody = document.getElementById('consultas-table-body');
    const btnAddConsulta = document.getElementById('btn-add-consulta');
    const btnSalvarConsulta = document.getElementById('btn-salvar-consulta');
    const consultaModal = new bootstrap.Modal(document.getElementById('consultaModal'));
    const consultaForm = document.getElementById('consultaForm');
    const medicoCrmInput = document.getElementById('consulta-medico-crm');
    const pacienteIdInput = document.getElementById('consulta-paciente-id');
    const medicoInfoDiv = document.getElementById('medico-info');
    const pacienteInfoDiv = document.getElementById('paciente-info');
    
    // Variáveis de estado
    let currentConsultaIndex = null;
    let medicos = [];
    let pacientes = [];
    let consultas = [];
    
    // Event Listeners
    btnAddConsulta.addEventListener('click', () => {
        openConsultaModal();
    });
    
    btnSalvarConsulta.addEventListener('click', () => {
        saveConsulta();
    });
    
    medicoCrmInput.addEventListener('blur', async function() {
        const crm = this.value;
        if (crm) {
            const medico = await buscarMedicoPorCrm(crm);
            if (medico) {
                medicoInfoDiv.textContent = `Médico: ${medico.nome} - ${medico.tipo || 'Sem especialidade'}`;
            } else {
                medicoInfoDiv.textContent = 'Médico não encontrado';
            }
        }
    });
    
    pacienteIdInput.addEventListener('blur', async function() {
        const id = this.value;
        if (id) {
            const paciente = await buscarPacientePorId(id);
            if (paciente) {
                pacienteInfoDiv.textContent = `Paciente: ${paciente.nome}`;
            } else {
                pacienteInfoDiv.textContent = 'Paciente não encontrado';
            }
        }
    });
    
    // Funções
    window.loadConsultas = async function() {
        try {
            medicos = await getMedicos();
            pacientes = await getPacientes();
            consultas = await getConsultas();
            
            console.log('Médicos:', medicos);
            console.log('Pacientes:', pacientes);
            
            if (consultas) {
                renderConsultasTable(consultas);
            }
        } catch (error) {
            console.error('Erro ao carregar consultas:', error);
            showAlert('Erro ao carregar consultas', 'danger');
        }
    };
    
    function renderConsultasTable(consultas) {
        consultasTableBody.innerHTML = '';
        
        if (consultas.length === 0) {
            consultasTableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center">Nenhuma consulta agendada</td>
                </tr>
            `;
            return;
        }
        
        consultas.forEach((consulta, index) => {
            const medico = consulta.medico;
            const paciente = consulta.paciente;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${medico.nome} (${medico.crm})</td>
                <td>${paciente.nome} (${paciente.idPaciente})</td>
                <td>${formatDateTime(consulta.dataHora)}</td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary btn-edit-consulta" data-index="${index}">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-delete-consulta" data-index="${index}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            consultasTableBody.appendChild(row);
        });
        
        // Adiciona event listeners para os botões de edição e exclusão
        document.querySelectorAll('.btn-edit-consulta').forEach(btn => {
            btn.addEventListener('click', () => {
                const index = parseInt(btn.getAttribute('data-index'));
                editConsulta(index);
            });
        });
        
        document.querySelectorAll('.btn-delete-consulta').forEach(btn => {
            btn.addEventListener('click', () => {
                const index = parseInt(btn.getAttribute('data-index'));
                confirmDeleteConsulta(index);
            });
        });
    }
    
    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return '';
        const date = new Date(dateTimeStr);
        return date.toLocaleString('pt-BR');
    }
    
    function openConsultaModal(consulta = null) {
        currentConsultaIndex = null;
        consultaForm.reset();
        medicoInfoDiv.textContent = '';
        pacienteInfoDiv.textContent = '';
        document.getElementById('consultaModalTitle').textContent = 'Agendar Consulta';
        
        if (consulta) {
            document.getElementById('consultaModalTitle').textContent = 'Editar Consulta';
            document.getElementById('consulta-index').value = consulta.index || '';
            
            medicoCrmInput.value = consulta.medico?.crm || '';
            if (consulta.medico?.nome) {
                medicoInfoDiv.textContent = `Médico: ${consulta.medico.nome}`;
            }
            
            pacienteIdInput.value = consulta.paciente?.idPaciente || '';
            if (consulta.paciente?.nome) {
                pacienteInfoDiv.textContent = `Paciente: ${consulta.paciente.nome}`;
            }
            
            if (consulta.dataHora) {
                try {
                    const date = new Date(consulta.dataHora);
                    if (!isNaN(date.getTime())) {
                        const formattedDate = date.toISOString().slice(0, 16);
                        document.getElementById('consulta-data').value = formattedDate;
                    }
                } catch (e) {
                    console.error('Formato de data inválido:', consulta.dataHora);
                }
            }
            
            currentConsultaIndex = consulta.index;
        }
        
        consultaModal.show();
    }
    
    async function saveConsulta() {
        const medicoCrm = medicoCrmInput.value;
        const pacienteId = pacienteIdInput.value;
        const dataHora = document.getElementById('consulta-data').value;
        
        if (!medicoCrm || !pacienteId || !dataHora) {
            showAlert('Preencha todos os campos!', 'warning');
            return;
        }
        
        // Verifica se médico existe
        const medico = await buscarMedicoPorCrm(medicoCrm);
        if (!medico) {
            showAlert('Médico não encontrado! Verifique o CRM.', 'danger');
            return;
        }
        
        // Verifica se paciente existe
        const paciente = await buscarPacientePorId(pacienteId);
        if (!paciente) {
            showAlert('Paciente não encontrado! Verifique o ID.', 'danger');
            return;
        }
        
        const consulta = {
            medico: {
                crm: medico.crm,
                nome: medico.nome,
                tipo: medico.tipo
            },
            paciente: {
                idPaciente: paciente.idPaciente,
                nome: paciente.nome
            },
            dataHora: new Date(dataHora).toISOString()
        };
        
        try {
            let response;
            if (currentConsultaIndex !== null) {
                response = await updateConsulta(currentConsultaIndex, consulta);
            } else {
                response = await addConsulta(consulta);
            }
            
            if (response) {
                consultaModal.hide();
                loadConsultas();
                showAlert('Consulta agendada com sucesso!', 'success');
            }
        } catch (error) {
            console.error('Erro ao salvar consulta:', error);
            showAlert('Erro ao agendar consulta', 'danger');
        }
    }
    
    async function editConsulta(index) {
        if (consultas[index]) {
            openConsultaModal({
                ...consultas[index],
                index
            });
        }
    }
    
    function confirmDeleteConsulta(index) {
        const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
        document.getElementById('confirm-message').textContent = 'Tem certeza que deseja cancelar esta consulta?';
        
        document.getElementById('btn-confirm-delete').onclick = async function() {
            const response = await deleteConsulta(index);
            if (response) {
                confirmModal.hide();
                loadConsultas();
                showAlert('Consulta cancelada com sucesso!', 'success');
            }
        };
        
        confirmModal.show();
    }
    
    // Carrega as consultas quando a página é carregada
    loadConsultas();
});