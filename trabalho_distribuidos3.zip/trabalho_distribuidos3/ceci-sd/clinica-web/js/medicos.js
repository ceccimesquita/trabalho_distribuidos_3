document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const medicosTableBody = document.getElementById('medicos-table-body');
    const btnAddMedico = document.getElementById('btn-add-medico');
    const btnSalvarMedico = document.getElementById('btn-salvar-medico');
    const medicoModal = new bootstrap.Modal(document.getElementById('medicoModal'));
    const medicoForm = document.getElementById('medicoForm');
    const medicoTypeFilter = document.getElementById('medico-type-filter');
    
    // Elementos dos campos específicos de cada tipo
    const ortopedistaFields = document.getElementById('ortopedista-fields');
    const pediatraFields = document.getElementById('pediatra-fields');
    const psiquiatraFields = document.getElementById('psiquiatra-fields');
    
    // Variáveis de estado
    let currentMedicoCrm = null;
    let medicos = [];
    
    // Event Listeners
    btnAddMedico.addEventListener('click', () => {
        openMedicoModal();
    });
    
    btnSalvarMedico.addEventListener('click', () => {
        saveMedico();
    });
    
    medicoTypeFilter.addEventListener('change', () => {
        filterMedicos();
    });
    
    document.getElementById('medico-tipo').addEventListener('change', function() {
        const tipo = this.value;
        
        // Esconde todos os campos específicos
        ortopedistaFields.style.display = 'none';
        pediatraFields.style.display = 'none';
        psiquiatraFields.style.display = 'none';
        
        // Mostra apenas os campos relevantes para o tipo selecionado
        if (tipo === 'ortopedista') {
            ortopedistaFields.style.display = 'block';
        } else if (tipo === 'pediatra') {
            pediatraFields.style.display = 'block';
        } else if (tipo === 'psiquiatra') {
            psiquiatraFields.style.display = 'block';
        }
    });
    
    // Funções
    window.loadMedicos = async function() {
        medicos = await getMedicos();
        if (medicos) {
            filterMedicos();
        }
    };
    
    function filterMedicos() {
        const filter = medicoTypeFilter.value;
        
        let filteredMedicos = [...medicos];
        if (filter !== 'all') {
            filteredMedicos = medicos.filter(medico => {
                if (filter === 'ortopedista') return medico.tipo === 'ortopedista';
                if (filter === 'pediatra') return medico.tipo === 'pediatra';
                if (filter === 'psiquiatra') return medico.tipo === 'psiquiatra';
                return true;
            });
        }
        
        renderMedicosTable(filteredMedicos);
    }
    
    function renderMedicosTable(medicos) {
        medicosTableBody.innerHTML = '';
        
        if (medicos.length === 0) {
            medicosTableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center">Nenhum médico cadastrado</td>
                </tr>
            `;
            return;
        }
        
        medicos.forEach(medico => {
            let especialidade = '';
            
            if (medico.tipo === 'ortopedista') {
                especialidade = `Ortopedista - ${medico.areaEspecializada}`;
                if (medico.realizaCirurgia) especialidade += ' (Cirurgião)';
            } else if (medico.tipo === 'pediatra') {
                especialidade = `Pediatra - ${medico.faixaEtariaAtendida}`;
                if (medico.possuiEspecializacaoNeonatal) especialidade += ' (Neonatal)';
            } else if (medico.tipo === 'psiquiatra') {
                especialidade = 'Psiquiatra';
                if (medico.atendeOnline) especialidade += ' (Online)';
                especialidade += ` - ${medico.duracaoConsultaMin} min`;
            }
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${medico.crm}</td>
                <td>${medico.nome}</td>
                <td>${medico.contato}</td>
                <td>${especialidade}</td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary btn-edit-medico" data-crm="${medico.crm}">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-delete-medico" data-crm="${medico.crm}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            medicosTableBody.appendChild(row);
        });
        
        // Adiciona event listeners para os botões de edição e exclusão
        document.querySelectorAll('.btn-edit-medico').forEach(btn => {
            btn.addEventListener('click', () => {
                const crm = btn.getAttribute('data-crm');
                editMedico(crm);
            });
        });
        
        document.querySelectorAll('.btn-delete-medico').forEach(btn => {
            btn.addEventListener('click', () => {
                const crm = btn.getAttribute('data-crm');
                confirmDeleteMedico(crm);
            });
        });
    }
    
    function openMedicoModal(medico = null) {
        currentMedicoCrm = null;
        medicoForm.reset();
        document.getElementById('medicoModalTitle').textContent = 'Adicionar Médico';
        
        // Esconde todos os campos específicos
        ortopedistaFields.style.display = 'none';
        pediatraFields.style.display = 'none';
        psiquiatraFields.style.display = 'none';
        
        if (medico) {
            document.getElementById('medicoModalTitle').textContent = 'Editar Médico';
            document.getElementById('medico-tipo').value = medico.tipo;
            document.getElementById('medico-tipo').dispatchEvent(new Event('change'));
            
            document.getElementById('medico-nome').value = medico.nome;
            document.getElementById('medico-crm-input').value = medico.crm;
            document.getElementById('medico-contato').value = medico.contato;
            currentMedicoCrm = medico.crm;
            
            // Preenche os campos específicos
            if (medico.tipo === 'ortopedista') {
                document.getElementById('medico-area').value = medico.areaEspecializada;
                document.getElementById('medico-cirurgia').checked = medico.realizaCirurgia;
            } else if (medico.tipo === 'pediatra') {
                document.getElementById('medico-faixa-etaria').value = medico.faixaEtariaAtendida;
                document.getElementById('medico-neonatal').checked = medico.possuiEspecializacaoNeonatal;
            } else if (medico.tipo === 'psiquiatra') {
                document.getElementById('medico-online').checked = medico.atendeOnline;
                document.getElementById('medico-duracao').value = medico.duracaoConsultaMin;
            }
        }
        
        medicoModal.show();
    }
    
    async function saveMedico() {
        const tipo = document.getElementById('medico-tipo').value;
        const nome = document.getElementById('medico-nome').value;
        const crm = document.getElementById('medico-crm-input').value;
        const contato = document.getElementById('medico-contato').value;
        
        let medico = {
            tipo,
            nome,
            crm,
            contato
        };
        
        // Adiciona campos específicos
        if (tipo === 'ortopedista') {
            medico.areaEspecializada = document.getElementById('medico-area').value;
            medico.realizaCirurgia = document.getElementById('medico-cirurgia').checked;
        } else if (tipo === 'pediatra') {
            medico.faixaEtariaAtendida = document.getElementById('medico-faixa-etaria').value;
            medico.possuiEspecializacaoNeonatal = document.getElementById('medico-neonatal').checked;
        } else if (tipo === 'psiquiatra') {
            medico.atendeOnline = document.getElementById('medico-online').checked;
            medico.duracaoConsultaMin = parseInt(document.getElementById('medico-duracao').value);
        }
        
        let response;
        if (currentMedicoCrm) {
            response = await updateMedico(currentMedicoCrm, medico);
        } else {
            response = await addMedico(medico);
        }
        
        if (response) {
            medicoModal.hide();
            loadMedicos();
            showAlert('Médico salvo com sucesso!', 'success');
        }
    }
    
    async function editMedico(crm) {
        const medico = medicos.find(m => m.crm === crm);
        
        if (medico) {
            openMedicoModal(medico);
        }
    }
    
    function confirmDeleteMedico(crm) {
        const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
        document.getElementById('confirm-message').textContent = 'Tem certeza que deseja excluir este médico?';
        
        document.getElementById('btn-confirm-delete').onclick = async function() {
            const response = await deleteMedico(crm);
            if (response) {
                confirmModal.hide();
                loadMedicos();
                showAlert('Médico excluído com sucesso!', 'success');
            }
        };
        
        confirmModal.show();
    }
    
    // Carrega os médicos quando a página é carregada
    loadMedicos();
});