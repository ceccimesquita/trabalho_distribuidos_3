document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const pacientesTableBody = document.getElementById('pacientes-table-body');
    const btnAddPaciente = document.getElementById('btn-add-paciente');
    const btnSalvarPaciente = document.getElementById('btn-salvar-paciente');
    const pacienteModal = new bootstrap.Modal(document.getElementById('pacienteModal'));
    const pacienteForm = document.getElementById('pacienteForm');
    
    // Variáveis de estado
    let currentPacienteId = null;
    
    // Event Listeners
    btnAddPaciente.addEventListener('click', () => {
        openPacienteModal();
    });
    
    btnSalvarPaciente.addEventListener('click', () => {
        savePaciente();
    });
    
    // Funções
    window.loadPacientes = async function() {
        const pacientes = await getPacientes();
        if (pacientes) {
            renderPacientesTable(pacientes);
        }
    };
    
    function renderPacientesTable(pacientes) {
        pacientesTableBody.innerHTML = '';
        
        if (pacientes.length === 0) {
            pacientesTableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center">Nenhum paciente cadastrado</td>
                </tr>
            `;
            return;
        }
        
        pacientes.forEach(paciente => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${paciente.idPaciente}</td>
                <td>${paciente.nome}</td>
                <td>${paciente.contato}</td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary btn-edit-paciente" data-id="${paciente.idPaciente}">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-delete-paciente" data-id="${paciente.idPaciente}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            pacientesTableBody.appendChild(row);
        });
        
        // Adiciona event listeners para os botões de edição e exclusão
        document.querySelectorAll('.btn-edit-paciente').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                editPaciente(id);
            });
        });
        
        document.querySelectorAll('.btn-delete-paciente').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                confirmDeletePaciente(id);
            });
        });
    }
    
    function openPacienteModal(paciente = null) {
        currentPacienteId = null;
        pacienteForm.reset();
        document.getElementById('pacienteModalTitle').textContent = 'Adicionar Paciente';
        
        if (paciente) {
            document.getElementById('pacienteModalTitle').textContent = 'Editar Paciente';
            document.getElementById('paciente-id').value = paciente.idPaciente;
            document.getElementById('paciente-nome').value = paciente.nome;
            document.getElementById('paciente-idPaciente').value = paciente.idPaciente;
            document.getElementById('paciente-contato').value = paciente.contato;
            currentPacienteId = paciente.idPaciente;
        }
        
        pacienteModal.show();
    }
    
    async function savePaciente() {
        const nome = document.getElementById('paciente-nome').value;
        const idPaciente = document.getElementById('paciente-idPaciente').value;
        const contato = document.getElementById('paciente-contato').value;
        
        const paciente = {
            nome,
            idPaciente,
            contato: contato
        };
        
        let response;
        if (currentPacienteId) {
            response = await updatePaciente(currentPacienteId, paciente);
        } else {
            response = await addPaciente(paciente);
        }
        
        if (response) {
            pacienteModal.hide();
            loadPacientes();
            showAlert('Paciente salvo com sucesso!', 'success');
        }
    }
    
    async function editPaciente(id) {
        const pacientes = await getPacientes();
        const paciente = pacientes.find(p => p.idPaciente === id);
        
        if (paciente) {
            openPacienteModal(paciente);
        }
    }
    
    function confirmDeletePaciente(id) {
        const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
        document.getElementById('confirm-message').textContent = 'Tem certeza que deseja excluir este paciente?';
        
        document.getElementById('btn-confirm-delete').onclick = async function() {
            const response = await deletePaciente(id);
            if (response) {
                confirmModal.hide();
                loadPacientes();
                showAlert('Paciente excluído com sucesso!', 'success');
            }
        };
        
        confirmModal.show();
    }
    
    // Carrega os pacientes quando a página é carregada
    loadPacientes();
});