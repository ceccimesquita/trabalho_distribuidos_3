// Função para mostrar seções
function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
    
    // Carrega os dados da seção quando ela é exibida
    if (sectionId === 'pacientes-section' && typeof loadPacientes === 'function') {
        loadPacientes();
    } else if (sectionId === 'medicos-section' && typeof loadMedicos === 'function') {
        loadMedicos();
    } else if (sectionId === 'consultas-section' && typeof loadConsultas === 'function') {
        loadConsultas();
    }
}

// Event listeners para navegação
document.addEventListener('DOMContentLoaded', function() {
    // Configura navegação
    document.getElementById('nav-pacientes').addEventListener('click', function(e) {
        e.preventDefault();
        showSection('pacientes-section');
    });
    
    document.getElementById('nav-medicos').addEventListener('click', function(e) {
        e.preventDefault();
        showSection('medicos-section');
    });
    
    document.getElementById('nav-consultas').addEventListener('click', function(e) {
        e.preventDefault();
        showSection('consultas-section');
    });

    // Mostra a seção inicial
    showSection('pacientes-section');
});