
import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import requests

API_PACIENTES = "http://localhost:8080/api/pacientes"
API_MEDICOS = "http://localhost:8080/api/medicos"
API_CONSULTAS = "http://localhost:8080/api/consultas"

root = tk.Tk()
root.title("Sistema Clínica")
tabs = ttk.Notebook(root)
tabs.pack(expand=1, fill='both')

# --- Funções Paciente ---
def cadastrar_paciente():
    nome = entry_p_nome.get()
    id_paciente = entry_p_id.get()
    contato = entry_p_contato.get()
    if not (nome and id_paciente and contato):
        messagebox.showwarning("Aviso", "Preencha todos os campos.")
        return
    try:
        requests.post(API_PACIENTES, json={"nome": nome, "idPaciente": id_paciente, "contato": contato})
        listar_pacientes()
    except Exception as e:
        messagebox.showerror("Erro", str(e))

def listar_pacientes():
    try:
        res = requests.get(API_PACIENTES)
        tree_pacientes.delete(*tree_pacientes.get_children())
        for p in res.json():
            tree_pacientes.insert('', 'end', values=(p['idPaciente'], p['nome'], p['contato']))
    except Exception as e:
        messagebox.showerror("Erro", str(e))

def remover_paciente():
    sel = tree_pacientes.selection()
    if not sel: return
    id_ = tree_pacientes.item(sel[0])['values'][0]
    requests.delete(f"{API_PACIENTES}/{id_}")
    listar_pacientes()

# --- Funções Médicos ---
def atualizar_campos_medico(event=None):
    tipo = tipo_medico_var.get()
    if tipo == "Pediatra":
        lbl_extra1.config(text="Faixa Etária:")
        lbl_extra2.config(text="Especialização Neonatal")
    elif tipo == "Ortopedista":
        lbl_extra1.config(text="Área Especializada:")
        lbl_extra2.config(text="Realiza Cirurgia")
    elif tipo == "Psiquiatra":
        lbl_extra1.config(text="Duração (min):")
        lbl_extra2.config(text="Atende Online")
    entry_extra1.delete(0, tk.END)
    var_extra2.set(False)

def cadastrar_medico():
    nome = entry_m_nome.get()
    crm = entry_m_crm.get()
    contato = entry_m_contato.get()
    tipo = tipo_medico_var.get()
    if not (nome and crm and contato and tipo):
        messagebox.showwarning("Aviso", "Preencha todos os campos.")
        return

    medico = {
        "tipo": tipo.lower(),
        "nome": nome,
        "crm": crm,
        "contato": contato
    }

    if tipo == "Pediatra":
        medico["faixaEtariaAtendida"] = entry_extra1.get()
        medico["possuiEspecializacaoNeonatal"] = var_extra2.get()
    elif tipo == "Ortopedista":
        medico["areaEspecializada"] = entry_extra1.get()
        medico["realizaCirurgia"] = var_extra2.get()
    elif tipo == "Psiquiatra":
        medico["duracaoConsultaMin"] = int(entry_extra1.get())
        medico["atendeOnline"] = var_extra2.get()

    requests.post(API_MEDICOS, json=medico)
    listar_medicos()

def listar_medicos():
    try:
        res = requests.get(API_MEDICOS)
        tree_medicos.delete(*tree_medicos.get_children())
        for m in res.json():
            tree_medicos.insert('', 'end', values=(m['crm'], m['nome'], m['contato'], m['tipo']))
    except Exception as e:
        messagebox.showerror("Erro", str(e))

def remover_medico():
    sel = tree_medicos.selection()
    if not sel: return
    crm = tree_medicos.item(sel[0])['values'][0]
    requests.delete(f"{API_MEDICOS}/{crm}")
    listar_medicos()

def mostrar_detalhes_medico(event):
    sel = tree_medicos.selection()
    if not sel: return
    crm = tree_medicos.item(sel[0])['values'][0]
    m = requests.get(f"{API_MEDICOS}/{crm}").json()
    win = tk.Toplevel()
    win.title("Detalhes do Médico")
    text = tk.Text(win, width=50, height=15)
    text.pack(padx=10, pady=10)
    detalhes = f"Nome: {m['nome']}\nCRM: {m['crm']}\nContato: {m['contato']}\nTipo: {m['tipo'].capitalize()}\n"
    if m['tipo'] == "pediatra":
        detalhes += f"Faixa Etária: {m['faixaEtariaAtendida']}\nEspecialização Neonatal: {m['possuiEspecializacaoNeonatal']}"
    elif m['tipo'] == "ortopedista":
        detalhes += f"Área: {m['areaEspecializada']}\nCirurgia: {m['realizaCirurgia']}"
    elif m['tipo'] == "psiquiatra":
        detalhes += f"Online: {m['atendeOnline']}\nDuração: {m['duracaoConsultaMin']} min"
    text.insert("1.0", detalhes)
    text.config(state='disabled')

# --- Funções Consultas ---
def cadastrar_consulta():
    pid = entry_c_paciente.get()
    crm = entry_c_medico.get()
    data = date_picker.get_date().strftime("%Y-%m-%d")
    hora = spin_hora.get()
    minuto = spin_min.get()
    datahora = f"{data}T{hora}:{minuto}"
    resp_paciente = requests.get(f"{API_PACIENTES}/{pid}")
    if resp_paciente.status_code != 200:
        messagebox.showerror("Erro", f"Paciente com ID {pid} não encontrado.")
        return
    paciente = resp_paciente.json()

    resp_medico = requests.get(f"{API_MEDICOS}/{crm}")
    if resp_medico.status_code != 200:
        messagebox.showerror("Erro", f"Médico com CRM {crm} não encontrado.")
        return
    medico = resp_medico.json()

    requests.post(API_CONSULTAS, json={"paciente": paciente, "medico": medico, "dataHora": datahora})
    listar_consultas()

def listar_consultas():
    res = requests.get(API_CONSULTAS)
    tree_consultas.delete(*tree_consultas.get_children())
    for i, c in enumerate(res.json()):
        tree_consultas.insert('', 'end', values=(i, c['paciente']['nome'], c['medico']['nome'], c['dataHora']))

def remover_consulta():
    sel = tree_consultas.selection()
    if not sel: return
    idx = tree_consultas.item(sel[0])['values'][0]
    requests.delete(f"{API_CONSULTAS}/{idx}")
    listar_consultas()

# --- Abas ---
# Pacientes
frame_p = ttk.Frame(tabs); tabs.add(frame_p, text="Pacientes")
entry_p_nome = tk.Entry(frame_p); entry_p_id = tk.Entry(frame_p); entry_p_contato = tk.Entry(frame_p)
for label, widget in zip(("Nome", "ID", "Contato"), (entry_p_nome, entry_p_id, entry_p_contato)):
    tk.Label(frame_p, text=label).pack(); widget.pack()
tk.Button(frame_p, text="Cadastrar", command=cadastrar_paciente).pack()
tree_pacientes = ttk.Treeview(frame_p, columns=("ID", "Nome", "Contato"), show="headings")
for col in ("ID", "Nome", "Contato"): tree_pacientes.heading(col, text=col)
tree_pacientes.pack(); tk.Button(frame_p, text="Atualizar", command=listar_pacientes).pack()
tk.Button(frame_p, text="Remover", command=remover_paciente).pack()

# Médicos
frame_m = ttk.Frame(tabs); tabs.add(frame_m, text="Médicos")
entry_m_nome = tk.Entry(frame_m); entry_m_crm = tk.Entry(frame_m); entry_m_contato = tk.Entry(frame_m)
tipo_medico_var = tk.StringVar(); entry_extra1 = tk.Entry(frame_m); var_extra2 = tk.BooleanVar()
for label, widget in zip(("Nome", "CRM", "Contato"), (entry_m_nome, entry_m_crm, entry_m_contato)):
    tk.Label(frame_m, text=label).pack(); widget.pack()
tk.Label(frame_m, text="Tipo").pack()
combo_tipo = ttk.Combobox(frame_m, textvariable=tipo_medico_var, values=["Pediatra", "Ortopedista", "Psiquiatra"])
combo_tipo.pack(); combo_tipo.bind("<<ComboboxSelected>>", atualizar_campos_medico)
lbl_extra1 = tk.Label(frame_m, text="Extra 1"); lbl_extra1.pack(); entry_extra1.pack()
lbl_extra2 = tk.Label(frame_m, text="Extra 2"); lbl_extra2.pack()
tk.Checkbutton(frame_m, variable=var_extra2).pack()
tk.Button(frame_m, text="Cadastrar", command=cadastrar_medico).pack()
tree_medicos = ttk.Treeview(frame_m, columns=("CRM", "Nome", "Contato", "Tipo"), show="headings")
for col in ("CRM", "Nome", "Contato", "Tipo"): tree_medicos.heading(col, text=col)
tree_medicos.pack(); tree_medicos.bind("<Double-1>", mostrar_detalhes_medico)
tk.Button(frame_m, text="Atualizar", command=listar_medicos).pack()
tk.Button(frame_m, text="Remover", command=remover_medico).pack()

# Consultas
frame_c = ttk.Frame(tabs); tabs.add(frame_c, text="Consultas")
entry_c_paciente = tk.Entry(frame_c); entry_c_medico = tk.Entry(frame_c)
tk.Label(frame_c, text="ID Paciente").pack(); entry_c_paciente.pack()
tk.Label(frame_c, text="CRM Médico").pack(); entry_c_medico.pack()
tk.Label(frame_c, text="Data").pack(); date_picker = DateEntry(frame_c); date_picker.pack()
tk.Label(frame_c, text="Hora").pack()
frame_hora = tk.Frame(frame_c); frame_hora.pack()
spin_hora = tk.Spinbox(frame_hora, from_=0, to=23, width=3, format="%02.0f"); spin_hora.pack(side=tk.LEFT)
tk.Label(frame_hora, text=":").pack(side=tk.LEFT)
spin_min = tk.Spinbox(frame_hora, from_=0, to=59, width=3, format="%02.0f"); spin_min.pack(side=tk.LEFT)
tk.Button(frame_c, text="Agendar", command=cadastrar_consulta).pack()
tree_consultas = ttk.Treeview(frame_c, columns=("ID", "Paciente", "Médico", "DataHora"), show="headings")
for col in ("ID", "Paciente", "Médico", "DataHora"): tree_consultas.heading(col, text=col)
tree_consultas.pack(); tk.Button(frame_c, text="Atualizar", command=listar_consultas).pack()
tk.Button(frame_c, text="Remover", command=remover_consulta).pack()

listar_pacientes()
listar_medicos()
listar_consultas()
root.mainloop()